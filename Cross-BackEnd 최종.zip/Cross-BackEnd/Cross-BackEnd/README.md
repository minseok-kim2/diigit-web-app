## Cross (AI 기반 여행지/경로 추천 서비스)

성향 테스트 결과와 여행 설정을 기반으로, 공공 관광 API 데이터를 결합해 맞춤형 여행지와 경로를 추천하는 서비스입니다.

### 핵심 기능
- 성향 테스트 결과 저장 및 사용자 유형 도출
- 여행 설정(목적지/기간/인원) 기반 추천 리스트 반환
- 공공 관광 API 연동 및 실패 시 DB 폴백
- JWT 기반 API 인증, 세션 기반 웹 로그인 병행

### 기술 스택
- Spring Boot, Spring Security, JWT, JPA, MySQL
- 공공 관광 API 연동

### 아키텍처 요약
- 3-Layer 구조 (Controller/Service/Repository)
- DTO를 통한 API 응답 분리 (엔티티 직접 반환 지양)
- 추천 로직은 성향 키워드 + 목적지 키워드 + 공공 API 태그 기반 점수화

## 실행 방법

### 1) 환경 변수
- `JWT_SECRET`: JWT 서명 키
- `TOUR_API_KEY`: 공공 관광 API 키(선택)

### 2) 실행
```bash
./gradlew bootRun
```

## API 요약

### 인증
- `POST /api/auth/login`
  - 요청: `{ "email": "...", "password": "..." }`
  - 응답: `{ "token": "...", "tokenType": "Bearer" }`

### 추천
- `GET /api/recommendations`
  - 헤더: `Authorization: Bearer <token>`
  - 응답: 사용자 유형/추천 리스트/경로

## 문서
- 추천 API/시퀀스: `cross/docs/recommendation.md`
- 인증 정책: `cross/docs/auth.md`

## 프로젝트 성과
- 한국정보기술전략혁신학회 논문 우수상

## 데모 캡처 (선택)
- 추후 이미지/시연 링크 추가 예정

