package com.example.cross.service;

import com.example.cross.entity.User;
import com.example.cross.repository.UserRepository;
// import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    // private final PasswordEncoder passwordEncoder;

    public User register(String username, String rawPassword) {
        if (userRepository.findByUsername(username).isPresent()) {
            throw new IllegalArgumentException("이미 존재하는 아이디입니다: " + username);
        }
        String encodedPassword = rawPassword; // TODO: enable BCrypt when Spring Security added
        User user = User.builder()
                .email(username)
                .name(username)
                .phone("")
                .password(encodedPassword)
                .build();
        return userRepository.save(user);
    }

    public boolean login(String username, String rawPassword) {
        return userRepository.findByUsername(username)
                .map(user -> user.getPassword().equals(rawPassword))
                .orElse(false);
    }
}
