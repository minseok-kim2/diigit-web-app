// NOTE: This file contained duplicated classes and malformed content.
// Keeping one clean implementation below.

package com.example.cross.service;

import com.example.cross.dto.AnswerDto;
import com.example.cross.dto.QuestionDto;
import com.example.cross.dto.ResultDto;
import com.example.cross.dto.SubmitRequestDto;
import com.example.cross.entity.User;
import com.example.cross.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class TestService {

    private final UserRepository userRepository;

    public List<QuestionDto> getQuestions() {
        return Arrays.asList(
                new QuestionDto(1L, "Q1. 해외여행까지 한 달 남았을 때의 나는?", Arrays.asList(
                        new AnswerDto("A", "어디 가지? 뭐 먹지? 하나부터 열까지 꼼꼼히 찾아본다."),
                        new AnswerDto("B", "비행기 티켓만 있으면 됐지! 나머진 천천히 생각해본다.")
                )),
                new QuestionDto(2L, "Q2. 여행 갔을 때 나의 주요 활동은?", Arrays.asList(
                        new AnswerDto("A", "스릴 넘치는 액티비티"),
                        new AnswerDto("B", "미술관, 박물관 등 문화 탐방"),
                        new AnswerDto("C", "휴양")
                )),
                new QuestionDto(3L, "Q3. 나의 지출 스타일은?", Arrays.asList(
                        new AnswerDto("A", "가성비를 따져서 알뜰하게"),
                        new AnswerDto("B", "돈을 지출하더라도 원하는 건 다 해야한다.")
                )),
                new QuestionDto(4L, "Q4. 숙소를 선택하는 기준은?", Arrays.asList(
                        new AnswerDto("A", "실속형! 교통이 편리하고 가격도 합리적인 곳으로"),
                        new AnswerDto("B", "숙소도 여행의 일부! 뷰, 인테리어 좋은 곳")
                )),
                new QuestionDto(5L, "Q5. 나의 여행 스타일은?", Arrays.asList(
                        new AnswerDto("A", "내가 언제 여길 다시 오겠어 이곳 저곳에 바쁘게 돌아다니는 편"),
                        new AnswerDto("B", "여유로운게 좋아 느긋하게 한 두곳만 파는 편")
                )),
                new QuestionDto(6L, "Q6. 여행 메이트는?", Arrays.asList(
                        new AnswerDto("A", "나 혼자서도 충분"),
                        new AnswerDto("B", "친구나 가족과 함께")
                )),
                new QuestionDto(7L, "Q7. 여행 중 뜻밖의 상황이 생겼을 때의 나는?", Arrays.asList(
                        new AnswerDto("A", "오히려 좋아! 이것도 특별한 추억이지"),
                        new AnswerDto("B", "예측 불가능한 상황은 싫어 피하고 싶어")
                ))
        );
    }

    @Transactional
    public ResultDto calculateResult(SubmitRequestDto submitRequestDto) {
        Map<String, Integer> scores = new HashMap<>();
        scores.put("PLANNER", 0);
        scores.put("EXPLORER", 0);
        scores.put("HEALER", 0);
        scores.put("SEEKER", 0);
        Map<Long, String> answers = submitRequestDto.getAnswers();
        if ("A".equals(answers.get(1L))) { scores.merge("PLANNER", 1, Integer::sum); scores.merge("SEEKER", 1, Integer::sum); } else { scores.merge("EXPLORER", 1, Integer::sum); }
        switch (answers.getOrDefault(2L, "")) {
            case "A": scores.merge("EXPLORER", 1, Integer::sum); break;
            case "B": scores.merge("SEEKER", 1, Integer::sum); break;
            case "C": scores.merge("HEALER", 1, Integer::sum); break;
        }
        if ("A".equals(answers.get(3L))) { scores.merge("PLANNER", 1, Integer::sum); } else { scores.merge("HEALER", 1, Integer::sum); scores.merge("EXPLORER", 1, Integer::sum); }
        if ("A".equals(answers.get(4L))) { scores.merge("PLANNER", 1, Integer::sum); } else { scores.merge("HEALER", 1, Integer::sum); }
        if ("A".equals(answers.get(5L))) { scores.merge("PLANNER", 1, Integer::sum); scores.merge("EXPLORER", 1, Integer::sum); } else { scores.merge("HEALER", 1, Integer::sum); scores.merge("SEEKER", 1, Integer::sum); }
        if ("A".equals(answers.get(6L))) { scores.merge("EXPLORER", 1, Integer::sum); } else { scores.merge("HEALER", 1, Integer::sum); }
        if ("A".equals(answers.get(7L))) { scores.merge("EXPLORER", 1, Integer::sum); } else { scores.merge("PLANNER", 1, Integer::sum); scores.merge("SEEKER", 1, Integer::sum); }

        String resultTypeKey = Collections.max(scores.entrySet(), Map.Entry.comparingByValue()).getKey();
        ResultDto resultDto = getResultDtoByType(resultTypeKey);

        Long userId = submitRequestDto.getUserId();
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("해당 ID의 사용자를 찾을 수 없습니다: " + userId));
        user.setResultType(resultDto.getType());
        userRepository.save(user);
        return resultDto;
    }

    private ResultDto getResultDtoByType(String type) {
        switch (type) {
            case "PLANNER":
                return new ResultDto("꼼꼼한 계획가", "J형이세요? 당신은 완벽한 여행 플래너!", "여행의 시작은 계획부터! 당신은 꼼꼼한 정보 수집과 체계적인 일정으로 여행의 모든 순간을 완벽하게 만듭니다. 당신과 함께라면 어떤 여행이든 실패란 없겠네요.");
            case "EXPLORER":
                return new ResultDto("자유로운 탐험가", "가방 하나 메고 어디든! 당신은 진정한 모험가!", "정해진 길보다는 새로운 길을, 예측 가능한 것보다는 짜릿한 경험을 즐기는 당신! 당신의 여행은 언제나 활기와 스릴이 넘칩니다. 오늘은 또 어떤 새로운 곳을 발견하게 될까요?");
            case "HEALER":
                return new ResultDto("감성적인 힐링 여행자", "여행은 휴식이죠! 당신은 진정한 힐링 마스터!", "북적이는 관광지보다는 고즈넉한 풍경 속에서 여유를 만끽하는 것을 즐깁니다. 맛있는 음식, 아름다운 숙소와 함께하는 당신의 여행은 지친 일상에 완벽한 쉼표가 되어줍니다.");
            case "SEEKER":
                return new ResultDto("지적인 문화 탐방가", "아는 만큼 보인다! 당신은 스마트한 여행자!", "여행지에서 박물관이나 미술관을 그냥 지나치지 못하는 당신. 현지의 역사와 문화를 깊이 있게 탐방하며 지적인 즐거움을 찾습니다. 당신의 여행은 단순한 관광을 넘어 깊은 배움의 과정입니다.");
            default:
                return new ResultDto("알 수 없는 유형", "당신은 종잡을 수 없는 매력의 소유자!", "어떤 유형으로도 정의할 수 없는 당신! 상황에 따라, 기분에 따라 자유자재로 여행 스타일을 바꾸는 당신은 최고의 여행 메이트일지도 모릅니다.");
        }
    }
}

