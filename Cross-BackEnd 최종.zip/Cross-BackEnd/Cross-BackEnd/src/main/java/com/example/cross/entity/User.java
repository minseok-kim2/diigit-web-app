package com.example.cross.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**

 사용자 정보를 나타내는 엔티티 클래스입니다.
 두 개의 User 클래스를 병합하여 모든 필드와 유효성 검사를 포함합니다.*/
@Entity
@Table(name = "users") // 'user'는 예약어일 수 있으므로 'users'를 사용합니다.
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED) // JPA 엔티티는 기본 생성자가 필요하며, 외부에서의 무분별한 생성을 막기 위해 protected로 설정합니다.
@AllArgsConstructor
@Builder // 빌더 패턴을 사용하여 객체 생성을 용이하게 합니다.
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long id;

    @NotBlank(message = "이름은 필수 입력 항목입니다.")
    @Size(max = 50)
    @Column(name = "name", nullable = false, length = 50)
    private String name;

    @NotBlank(message = "전화번호는 필수 입력 항목입니다.")
    @Size(max = 20)
    @Column(name = "phone", nullable = false, length = 20)
    private String phone;

    @NotBlank(message = "이메일은 필수 입력 항목입니다.")
    @Email(message = "유효한 이메일 형식이 아닙니다.")
    @Size(max = 100)
    @Column(name = "email", nullable = false, unique = true, length = 100)
    private String email; // 로그인 시 username 대신 사용할 고유 식별자

    @NotBlank(message = "비밀번호는 필수 입력 항목입니다.")
    @Size(min = 8, max = 255, message = "비밀번호는 8자 이상이어야 합니다.")
    @Column(name = "password", nullable = false, length = 255)
    private String password; // 암호화된 비밀번호 저장

    @Column(name = "result_type", length = 50)
    private String resultType; // 성향 테스트 결과 타입
}