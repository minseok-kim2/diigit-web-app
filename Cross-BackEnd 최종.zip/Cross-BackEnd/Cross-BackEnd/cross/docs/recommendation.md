## 추천 API

### GET /api/recommendations
- 설명: 로그인 사용자 기준으로 성향 + 여행설정 + 공공 API 후보를 결합해 추천/경로 반환
- 인증: 로그인 세션 필요
- 실패 처리: 공공 API 실패/빈 응답 시 DB 후보만으로 추천 진행

#### 응답 예시
```json
{
  "userType": "감성적인 힐링 여행자",
  "destination": "제주",
  "startDate": "2026-02-01",
  "endDate": "2026-02-05",
  "numPeople": "2",
  "places": [
    {
      "name": "Jeju Olle Trail",
      "description": "자연과 함께하는 힐링 트레킹 코스.",
      "address": "Jeju, South Korea",
      "source": "DB",
      "score": 6,
      "reason": "여행지 키워드 일치 | 성향 키워드 일치: 힐링, 자연"
    }
  ],
  "route": [
    { "order": 1, "name": "Jeju Olle Trail", "address": "Jeju, South Korea" }
  ]
}
```

## 시퀀스 다이어그램

```mermaid
sequenceDiagram
    actor User
    participant Client
    participant API as RecommendationController
    participant Svc as RecommendationService
    participant DB as MySQL
    participant PublicAPI as 공공 API

    User->>Client: 추천 요청
    Client->>API: GET /api/recommendations
    API->>Svc: recommendForUser(email)
    Svc->>DB: User/TravelSetting/Place 조회
    Svc->>PublicAPI: destination 기반 검색
    Svc->>Svc: 성향 키워드 매칭 + 점수화
    Svc-->>API: 추천 리스트/경로 응답
    API-->>Client: JSON 반환
```

