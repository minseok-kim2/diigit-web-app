## 인증 정책

- 웹 페이지: 세션 기반 폼 로그인 사용
- API: JWT 기반 인증 사용

### API 로그인
`POST /api/auth/login`

응답으로 받은 토큰을 아래 헤더에 넣어서 호출합니다.
`Authorization: Bearer <token>`

### 분리 이유
- 웹 페이지는 기존 세션 기반 흐름 유지
- 외부/모바일 연동 가능성을 위해 API는 JWT로 분리

