package com.example.cross.controller;

import com.example.cross.entity.TravelSetting;
import com.example.cross.entity.User;
import com.example.cross.repository.TravelSettingRepository;
import com.example.cross.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/travel-setting")
public class TravelSettingController {

    private final TravelSettingRepository travelSettingRepository;
    private final UserRepository userRepository;

    public TravelSettingController(TravelSettingRepository travelSettingRepository, UserRepository userRepository) {
        this.travelSettingRepository = travelSettingRepository;
        this.userRepository = userRepository;
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestBody Map<String, String> body, Authentication auth) {
        String email = auth != null ? auth.getName() : null;
        if (email == null) return ResponseEntity.status(401).body("로그인이 필요합니다");
        User user = userRepository.findByEmail(email).orElse(null);
        if (user == null) return ResponseEntity.status(401).body("사용자를 찾을 수 없습니다");

        TravelSetting ts = new TravelSetting();
        ts.setUser(user);
        ts.setDestination(body.getOrDefault("destination", ""));
        String sd = body.get("startDate");
        String ed = body.get("endDate");
        ts.setStartDate(sd != null && !sd.isBlank() ? LocalDate.parse(sd) : null);
        ts.setEndDate(ed != null && !ed.isBlank() ? LocalDate.parse(ed) : null);
        ts.setNumPeople(body.getOrDefault("numPeople", null));
        ts.setMemo(body.getOrDefault("memo", null));
        travelSettingRepository.save(ts);
        return ResponseEntity.ok(Map.of("ok", true, "id", ts.getId()));
    }
}


