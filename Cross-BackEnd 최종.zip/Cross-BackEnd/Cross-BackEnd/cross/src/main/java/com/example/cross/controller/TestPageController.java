package com.example.cross.controller;

import com.example.cross.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TestPageController {

    private final UserRepository userRepository;

    public TestPageController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/personality-test")
    public String testPage(Authentication auth, Model model) {
        Long userId = null;
        if (auth != null && auth.getName() != null) {
            userId = userRepository.findByEmail(auth.getName()).map(u -> u.getId()).orElse(null);
        }
        model.addAttribute("userId", userId);
        return "personality-test";
    }
}
