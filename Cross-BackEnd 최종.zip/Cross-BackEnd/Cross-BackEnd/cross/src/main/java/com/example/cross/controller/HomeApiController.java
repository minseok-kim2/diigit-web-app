package com.example.cross.controller;

import com.example.cross.dto.PlaceCardDto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Random;

@RestController
@RequestMapping("/api/home")
public class HomeApiController {

    /**
     * GET /api/home/favorites
     * 설명: 메인 홈 화면의 '즐겨찾기' 카드 목록을 반환합니다.
     * 응답: List<PlaceCardDto> (image: 이미지 URL, title: 카드 제목, flag: 국가 깃발 URL 선택값)
     * 사용처: templates/index.html → fetchJson('/api/home/favorites')
     */
    @GetMapping("/favorites")
    public List<PlaceCardDto> favorites() {
        return List.of(
                new PlaceCardDto(
                        "https://images.unsplash.com/photo-1542051841857-5f90071e7989?q=80&w=2070&auto=format&fit=crop",
                        "도쿄 (일본)",
                        "https://upload.wikimedia.org/wikipedia/en/thumb/9/9e/Flag_of_Japan.svg/320px-Flag_of_Japan.svg.png"
                ),
                new PlaceCardDto(
                        "https://images.unsplash.com/photo-1528181304800-259b08848526?q=80&w=2070&auto=format&fit=crop",
                        "방콕 (태국)",
                        "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Flag_of_Thailand.svg/320px-Flag_of_Thailand.svg.png"
                )
        );
    }

    /**
     * GET /api/home/recommended
     * 설명: 메인 홈 화면의 '이런 여행지는 어떠세요?' 추천 카드 목록을 반환합니다.
     * 응답: List<PlaceCardDto> (image: 이미지 URL, title: 카드 제목, flag: null)
     * 사용처: templates/index.html → fetchJson('/api/home/recommended')
     */
    @GetMapping("/recommended")
    public List<PlaceCardDto> recommended() {
        return List.of(
                new PlaceCardDto(
                        "https://images.unsplash.com/photo-1513407030348-c983a97b98d8?q=80&w=2072&auto=format&fit=crop",
                        "도쿄타워",
                        null
                ),
                new PlaceCardDto(
                        "https://images.unsplash.com/photo-1563492065599-3520f775ee09?q=80&w=1974&auto=format&fit=crop",
                        "왓 포 사원",
                        null
                )
        );
    }

    /**
     * GET /api/home/how-travel-location
     * 설명: 후보 풀에서 임의의 여행지 1개를 랜덤으로 반환합니다(데모용).
     * 응답: PlaceCardDto (image, title, flag=null)
     * 사용처: 추후 홈 화면/이벤트 등에서 랜덤 추천 노출 시 활용 가능
     */
    @GetMapping("/how-travel-location")
    public PlaceCardDto randomLocation() {
        List<PlaceCardDto> pool = List.of(
                new PlaceCardDto("https://images.unsplash.com/photo-1542051841857-5f90071e7989?q=80&w=2070&auto=format&fit=crop", "도쿄", null),
                new PlaceCardDto("https://images.unsplash.com/photo-1563492065599-3520f775ee09?q=80&w=1974&auto=format&fit=crop", "방콕", null),
                new PlaceCardDto("https://images.unsplash.com/photo-1526481280698-8fcc13fdc0db?q=80&w=2070&auto=format&fit=crop", "제주도", null),
                new PlaceCardDto("https://images.unsplash.com/photo-1512453979798-5ea266f8880c?q=80&w=2070&auto=format&fit=crop", "파리", null)
        );
        return pool.get(new Random().nextInt(pool.size()));
    }

    /**
     * POST /api/home/travel-setting
     * 설명: 여행 설정 폼 데이터를 수신하여 그대로 에코하는 데모용 엔드포인트입니다.
     * 요청: JSON 임의 구조(Map)
     * 응답: { ok: true, received: <요청본문> }
     */
    @PostMapping("/travel-setting")
    public Map<String, Object> saveTravelSetting(@RequestBody Map<String, Object> body) {
        return Map.of("ok", true, "received", body);
    }
}


