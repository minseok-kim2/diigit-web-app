package com.example.cross.controller;

import com.example.cross.dto.RecommendationResponseDto;
import com.example.cross.service.RecommendationService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/recommendations")
public class RecommendationController {
	private final RecommendationService recommendationService;

	public RecommendationController(RecommendationService recommendationService) {
		this.recommendationService = recommendationService;
	}

	@GetMapping
	public ResponseEntity<RecommendationResponseDto> recommend(Authentication auth) {
		if (auth == null || auth.getName() == null) {
			return ResponseEntity.status(401).build();
		}
		try {
			RecommendationResponseDto response = recommendationService.recommendForUser(auth.getName());
			return ResponseEntity.ok(response);
		} catch (EntityNotFoundException ex) {
			return ResponseEntity.status(404).build();
		}
	}
}

