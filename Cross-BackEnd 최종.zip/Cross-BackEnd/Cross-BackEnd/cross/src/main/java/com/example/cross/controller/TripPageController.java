package com.example.cross.controller;

import com.example.cross.entity.TravelSetting;
import com.example.cross.entity.User;
import com.example.cross.repository.TravelSettingRepository;
import com.example.cross.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@Controller
public class TripPageController {

    private final TravelSettingRepository travelSettingRepository;
    private final UserRepository userRepository;

    public TripPageController(TravelSettingRepository travelSettingRepository, UserRepository userRepository) {
        this.travelSettingRepository = travelSettingRepository;
        this.userRepository = userRepository;
    }

    @GetMapping("/trip/itinerary")
    public String itinerary(@RequestParam(name = "tsId", required = false) Long tsId,
                            Authentication auth,
                            Model model) {
        TravelSetting setting = null;
        if (tsId != null) {
            setting = travelSettingRepository.findById(tsId).orElse(null);
        } else if (auth != null) {
            Optional<User> u = userRepository.findByEmail(auth.getName());
            if (u.isPresent()) {
                var list = travelSettingRepository.findByUser(u.get());
                if (!list.isEmpty()) setting = list.get(list.size() - 1);
            }
        }
        model.addAttribute("setting", setting);
        return "itinerary";
    }

    @GetMapping("/trip/place")
    public String placeDetail(@RequestParam(name = "name") String name,
                              Model model) {
        model.addAttribute("name", name);
        return "place-detail";
    }
}


