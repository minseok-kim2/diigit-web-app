package com.example.cross.controller;

import com.example.cross.dto.LoginRequestDto;
import com.example.cross.dto.LoginResponseDto;
import com.example.cross.service.JwtTokenProvider;
import com.example.cross.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class AuthApiController {
	private final UserService userService;
	private final JwtTokenProvider jwtTokenProvider;

	public AuthApiController(UserService userService, JwtTokenProvider jwtTokenProvider) {
		this.userService = userService;
		this.jwtTokenProvider = jwtTokenProvider;
	}

	@PostMapping("/login")
	public ResponseEntity<LoginResponseDto> login(@Valid @RequestBody LoginRequestDto request) {
		boolean ok = userService.login(request.getEmail(), request.getPassword());
		if (!ok) {
			return ResponseEntity.status(401).build();
		}
		String token = jwtTokenProvider.createToken(request.getEmail(), "ROLE_USER");
		return ResponseEntity.ok(new LoginResponseDto(token, "Bearer"));
	}
}

