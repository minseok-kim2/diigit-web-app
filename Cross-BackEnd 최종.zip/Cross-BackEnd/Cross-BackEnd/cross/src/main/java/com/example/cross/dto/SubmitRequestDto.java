package com.example.cross.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;

/**
 * 사용자의 답변 제출 요청을 받는 객체
 */
@Getter
@Setter
public class SubmitRequestDto {

    // "어떤 사용자의 결과를 저장할지" 알려주기 위한 ID
    @NotNull(message = "사용자 ID는 필수입니다.")
    private Long userId;

    @NotNull
    @Size(min = 7, max = 7, message = "7개의 모든 질문에 답해야 합니다.")
    private Map<Long, String> answers; // Key: 질문 ID, Value: 선택한 답변 Key
}

