package com.example.cross.controller;

import com.example.cross.dto.PlaceResponseDto;
import com.example.cross.entity.Place;
import com.example.cross.repository.PlaceRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/places")
public class PlaceController {

    private final PlaceRepository placeRepository;

    public PlaceController(PlaceRepository placeRepository) {
        this.placeRepository = placeRepository;
    }

    @GetMapping
    public List<PlaceResponseDto> getPlaces() {
        return placeRepository.findAll().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<PlaceResponseDto> getPlaceById(@PathVariable Long id) {
        return placeRepository.findById(id)
                .map(place -> ResponseEntity.ok(toDto(place)))
                .orElse(ResponseEntity.notFound().build());
    }

    private PlaceResponseDto toDto(Place place) {
        return new PlaceResponseDto(
                place.getId(),
                place.getName(),
                place.getDescription(),
                place.getAddress()
        );
    }
}


