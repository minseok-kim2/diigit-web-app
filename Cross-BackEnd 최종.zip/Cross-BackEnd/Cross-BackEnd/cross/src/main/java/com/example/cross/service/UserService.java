package com.example.cross.service;

import com.example.cross.entity.User;
import com.example.cross.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public User register(String username, String rawPassword) {
        // username을 이메일로 사용
        Optional<User> existing = userRepository.findByEmail(username);
        if (existing.isPresent()) {
            throw new IllegalArgumentException("이미 존재하는 아이디입니다: " + username);
        }
        String encodedPassword = passwordEncoder.encode(rawPassword);
        User user = new User(null, username, "", username, encodedPassword, null);
        return userRepository.save(user);
    }

    public boolean login(String username, String rawPassword) {
        return userRepository.findByEmail(username)
                .map(user -> passwordEncoder.matches(rawPassword, user.getPassword()))
                .orElse(false);
    }

    public User registerWithProfile(String name, String phone, String email, String rawPassword) {
        Optional<User> existing = userRepository.findByEmail(email);
        if (existing.isPresent()) {
            throw new IllegalArgumentException("이미 존재하는 아이디입니다: " + email);
        }
        String encodedPassword = passwordEncoder.encode(rawPassword);
        User user = new User(null, name, phone, email, encodedPassword, null);
        return userRepository.save(user);
    }
}


