package com.example.cross.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 최종 결과를 프론트엔드로 보내는 객체
 */
@Getter
@AllArgsConstructor
public class ResultDto {
    private String type; // 결과 유형 (예: "꼼꼼한 계획가")
    private String title; // 결과 제목
    private String description; // 결과 상세 설명
}