package com.example.cross.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

	@GetMapping({"/", "/index"})
	public String index() {
		return "index";
	}

	@GetMapping("/api/main")
	public String apiMain() {
		return "index";
	}

	@GetMapping("/travel-setting")
	public String travelSetting() {
		return "travel-setting";
	}

	@GetMapping("/how-travel-location")
	public String howTravelLocation() {
		return "how-travel-location";
	}

	@GetMapping("/emergency")
	public String emergency() {
		return "emergency";
	}

	@GetMapping("/currency")
	public String currency() {
		return "currency";
	}

	@GetMapping("/map")
	public String map() {
		return "map";
	}

	@GetMapping("/mypage")
	public String mypage() {
		return "mypage";
	}

	@GetMapping("/place/{code}")
	public String place() {
		return "place";
	}

	@GetMapping("/favorites")
	public String favoritesPage() {
		// 즐겨찾기 전용 뷰. 클라이언트에서 /api/home/favorites를 호출하여 렌더링합니다.
		return "favorites";
	}
}


