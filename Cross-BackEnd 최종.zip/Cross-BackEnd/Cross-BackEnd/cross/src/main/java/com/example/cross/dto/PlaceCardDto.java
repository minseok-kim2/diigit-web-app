package com.example.cross.dto;

public class PlaceCardDto {
    private String image;
    private String title;
    private String flag;

    public PlaceCardDto() {}

    public PlaceCardDto(String image, String title, String flag) {
        this.image = image;
        this.title = title;
        this.flag = flag;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }
}


