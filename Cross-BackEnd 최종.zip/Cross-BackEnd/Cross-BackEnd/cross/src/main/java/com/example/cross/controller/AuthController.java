package com.example.cross.controller;

import com.example.cross.entity.User;
import com.example.cross.repository.UserRepository;
import com.example.cross.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController { // 로그인

    private final UserService userService;
    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/auth/login")
    public String loginPage() {
        return "login";
    }

    @GetMapping({"/auth/register", "/register"})
    public String registerPage() {
        return "register";
    }

    @PostMapping({"/auth/register", "/register"})
    public String register(@RequestParam("name") String name,
                           @RequestParam("phone") String phone,
                           @RequestParam("email") String email,
                           @RequestParam("password") String password,
                           @RequestParam(value = "passwordConfirm", required = false) String passwordConfirm) {
        if (passwordConfirm != null && !password.equals(passwordConfirm)) {
            return "redirect:/auth/register?error=pwd";
        }
        try {
            userService.registerWithProfile(name, phone, email, password);
        } catch (IllegalArgumentException e) {
            return "redirect:/auth/register?error=dup";
        }
        return "redirect:/auth/login?registered=true";
    }
}


