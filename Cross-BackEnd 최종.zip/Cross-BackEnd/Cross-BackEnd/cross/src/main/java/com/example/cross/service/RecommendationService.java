package com.example.cross.service;

import com.example.cross.dto.RecommendationResponseDto;
import com.example.cross.dto.RecommendedPlaceDto;
import com.example.cross.dto.RouteStepDto;
import com.example.cross.entity.Place;
import com.example.cross.entity.TravelSetting;
import com.example.cross.entity.User;
import com.example.cross.repository.PlaceRepository;
import com.example.cross.repository.TravelSettingRepository;
import com.example.cross.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

@Service
public class RecommendationService {
	private final UserRepository userRepository;
	private final TravelSettingRepository travelSettingRepository;
	private final PlaceRepository placeRepository;
	private final TourApiClient tourApiClient;

	public RecommendationService(UserRepository userRepository,
								 TravelSettingRepository travelSettingRepository,
								 PlaceRepository placeRepository,
								 TourApiClient tourApiClient) {
		this.userRepository = userRepository;
		this.travelSettingRepository = travelSettingRepository;
		this.placeRepository = placeRepository;
		this.tourApiClient = tourApiClient;
	}

	public RecommendationResponseDto recommendForUser(String email) {
		User user = userRepository.findByEmail(email)
				.orElseThrow(() -> new EntityNotFoundException("사용자를 찾을 수 없습니다: " + email));

		TravelSetting travelSetting = travelSettingRepository.findTopByUserOrderByIdDesc(user)
				.orElseThrow(() -> new EntityNotFoundException("여행 설정이 없습니다. 여행 설정을 먼저 저장해 주세요."));

		String userType = Optional.ofNullable(user.getResultType()).orElse("알 수 없는 유형");
		String destination = travelSetting.getDestination();
		List<Candidate> candidates = mergeCandidates(destination);
		List<RecommendedPlaceDto> places = rankAndMap(userType, destination, candidates);
		List<RouteStepDto> route = buildRoute(places);

		return new RecommendationResponseDto(
				userType,
				destination,
				travelSetting.getStartDate(),
				travelSetting.getEndDate(),
				travelSetting.getNumPeople(),
				places,
				route
		);
	}

	private List<Candidate> mergeCandidates(String destination) {
		Map<String, Candidate> unique = new LinkedHashMap<>();
		for (Place place : placeRepository.findAll()) {
			Candidate candidate = Candidate.fromDb(place);
			unique.putIfAbsent(candidate.key(), candidate);
		}

		List<TourApiClient.ExternalPlace> externals = tourApiClient.searchByKeyword(destination);
		for (TourApiClient.ExternalPlace ext : externals) {
			Candidate candidate = Candidate.fromExternal(ext);
			unique.putIfAbsent(candidate.key(), candidate);
		}

		return new ArrayList<>(unique.values());
	}

	private List<RecommendedPlaceDto> rankAndMap(String userType, String destination, List<Candidate> candidates) {
		Map<String, List<String>> keywordMap = new LinkedHashMap<>();
		keywordMap.put("꼼꼼한 계획가", List.of("교통", "도심", "효율", "핵심", "랜드마크"));
		keywordMap.put("자유로운 탐험가", List.of("액티비티", "탐험", "야외", "모험", "트레킹"));
		keywordMap.put("감성적인 힐링 여행자", List.of("힐링", "휴양", "자연", "온천", "해변"));
		keywordMap.put("지적인 문화 탐방가", List.of("문화", "역사", "박물관", "미술관", "전시"));

		List<String> keywords = keywordMap.getOrDefault(userType, List.of());

		return candidates.stream()
				.map(candidate -> scoreCandidate(candidate, destination, keywords))
				.sorted(Comparator.comparingInt(ScoredCandidate::score).reversed())
				.limit(6)
				.map(scored -> new RecommendedPlaceDto(
						scored.candidate().name,
						scored.candidate().description,
						scored.candidate().address,
						scored.candidate().source,
						scored.score(),
						scored.reason()
				))
				.toList();
	}

	private ScoredCandidate scoreCandidate(Candidate candidate, String destination, List<String> keywords) {
		int score = 0;
		List<String> reasons = new ArrayList<>();

		if (destination != null && !destination.isBlank()) {
			String dest = destination.toLowerCase(Locale.KOREAN);
			String address = candidate.address.toLowerCase(Locale.KOREAN);
			String name = candidate.name.toLowerCase(Locale.KOREAN);
			if (address.contains(dest) || name.contains(dest)) {
				score += 2;
				reasons.add("여행지 키워드 일치");
			}
		}

		String text = (candidate.name + " " + candidate.description).toLowerCase(Locale.KOREAN);
		List<String> matched = new ArrayList<>();
		for (String keyword : keywords) {
			if (text.contains(keyword.toLowerCase(Locale.KOREAN))) {
				score += 3;
				matched.add(keyword);
			}
		}
		if (!matched.isEmpty()) {
			reasons.add("성향 키워드 일치: " + String.join(", ", matched));
		}

		if (!candidate.tags.isEmpty()) {
			score += 1;
			reasons.add("공공 데이터 태그 반영");
		}

		if (reasons.isEmpty()) {
			reasons.add("기본 추천");
		}

		return new ScoredCandidate(candidate, score, String.join(" | ", reasons));
	}

	private List<RouteStepDto> buildRoute(List<RecommendedPlaceDto> places) {
		List<RouteStepDto> route = new ArrayList<>();
		for (int i = 0; i < places.size(); i++) {
			RecommendedPlaceDto place = places.get(i);
			route.add(new RouteStepDto(i + 1, place.getName(), place.getAddress()));
		}
		return route;
	}

	private record Candidate(String name, String description, String address, List<String> tags, String source) {
		String key() {
			return (name + "|" + address).toLowerCase(Locale.KOREAN);
		}

		static Candidate fromDb(Place place) {
			return new Candidate(
					Optional.ofNullable(place.getName()).orElse(""),
					Optional.ofNullable(place.getDescription()).orElse(""),
					Optional.ofNullable(place.getAddress()).orElse(""),
					List.of(),
					"DB"
			);
		}

		static Candidate fromExternal(TourApiClient.ExternalPlace ext) {
			return new Candidate(
					Optional.ofNullable(ext.getName()).orElse(""),
					Optional.ofNullable(ext.getDescription()).orElse(""),
					Optional.ofNullable(ext.getAddress()).orElse(""),
					Optional.ofNullable(ext.getTags()).orElse(List.of()),
					"PUBLIC_API"
			);
		}
	}

	private record ScoredCandidate(Candidate candidate, int score, String reason) {}
}

