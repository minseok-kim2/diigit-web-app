package com.example.cross.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

/**
 * 프론트엔드로 보낼 질문 객체
 */
@Getter
@AllArgsConstructor
public class QuestionDto {
    private long id; // 질문 고유 ID
    private String text; // 질문 내용
    private List<AnswerDto> answers; // 선택지 목록
}

