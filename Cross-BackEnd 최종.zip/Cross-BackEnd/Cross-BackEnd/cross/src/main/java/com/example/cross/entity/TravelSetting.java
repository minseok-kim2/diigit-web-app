package com.example.cross.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "travel_setting")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TravelSetting {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false)
	private User user;

	@Column(name = "destination", nullable = false, length = 100)
	private String destination;

	@Column(name = "start_date")
	private LocalDate startDate;

	@Column(name = "end_date")
	private LocalDate endDate;

	@Column(name = "num_people", length = 10)
	private String numPeople;

	@Lob
	@Column(name = "memo")
	private String memo;
}


