package com.example.cross.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class TourApiClient {
	private final RestClient restClient;
	private final ObjectMapper objectMapper;
	private final String searchPath;
	private final String serviceKey;
	private final String mobileOs;
	private final String mobileApp;
	private final int numOfRows;

	public TourApiClient(RestClient.Builder builder,
						 ObjectMapper objectMapper,
						 @Value("${tour.api.base-url}") String baseUrl,
						 @Value("${tour.api.search-path}") String searchPath,
						 @Value("${tour.api.service-key}") String serviceKey,
						 @Value("${tour.api.mobile-os:ETC}") String mobileOs,
						 @Value("${tour.api.mobile-app:Cross}") String mobileApp,
						 @Value("${tour.api.num-of-rows:20}") int numOfRows) {
		this.restClient = builder.baseUrl(baseUrl).build();
		this.objectMapper = objectMapper;
		this.searchPath = searchPath;
		this.serviceKey = serviceKey;
		this.mobileOs = mobileOs;
		this.mobileApp = mobileApp;
		this.numOfRows = numOfRows;
	}

	public List<ExternalPlace> searchByKeyword(String keyword) {
		if (keyword == null || keyword.isBlank() || serviceKey == null || serviceKey.isBlank()) {
			return Collections.emptyList();
		}

		String body = restClient.get()
				.uri(uriBuilder -> uriBuilder
						.path(searchPath)
						.queryParam("serviceKey", serviceKey)
						.queryParam("MobileOS", mobileOs)
						.queryParam("MobileApp", mobileApp)
						.queryParam("_type", "json")
						.queryParam("numOfRows", numOfRows)
						.queryParam("pageNo", 1)
						.queryParam("keyword", keyword)
						.build())
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.body(String.class);

		if (body == null || body.isBlank()) {
			return Collections.emptyList();
		}

		return parseItems(body);
	}

	private List<ExternalPlace> parseItems(String body) {
		try {
			JsonNode root = objectMapper.readTree(body);
			JsonNode items = root.path("response").path("body").path("items").path("item");
			if (!items.isArray()) {
				return Collections.emptyList();
			}
			List<ExternalPlace> results = new ArrayList<>();
			for (JsonNode item : items) {
				String title = item.path("title").asText("");
				String addr = item.path("addr1").asText("");
				String overview = item.path("overview").asText("");
				String cat1 = item.path("cat1").asText("");
				String cat2 = item.path("cat2").asText("");
				List<String> tags = new ArrayList<>();
				if (!cat1.isBlank()) {
					tags.add(cat1);
				}
				if (!cat2.isBlank()) {
					tags.add(cat2);
				}

				if (!title.isBlank()) {
					results.add(new ExternalPlace(title, overview, addr, tags));
				}
			}
			return results;
		} catch (Exception ex) {
			return Collections.emptyList();
		}
	}

	public static class ExternalPlace {
		private final String name;
		private final String description;
		private final String address;
		private final List<String> tags;

		public ExternalPlace(String name, String description, String address, List<String> tags) {
			this.name = name;
			this.description = description;
			this.address = address;
			this.tags = tags == null ? List.of() : tags;
		}

		public String getName() {
			return name;
		}

		public String getDescription() {
			return description;
		}

		public String getAddress() {
			return address;
		}

		public List<String> getTags() {
			return tags;
		}
	}
}

