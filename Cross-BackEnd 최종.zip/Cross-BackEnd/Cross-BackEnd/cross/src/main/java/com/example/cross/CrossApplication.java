package com.example.cross;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrossApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrossApplication.class, args);
	}

}
