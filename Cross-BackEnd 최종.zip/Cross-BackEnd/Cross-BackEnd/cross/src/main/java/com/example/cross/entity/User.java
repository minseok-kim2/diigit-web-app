package com.example.cross.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private Long id;

	@NotBlank
	@Size(max = 50)
	@Column(name = "name", nullable = false, length = 50)
	private String name;

	@NotBlank
	@Size(max = 20)
	@Column(name = "phone", nullable = false, length = 20)
	private String phone;

	@NotBlank
	@Email
	@Size(max = 100)
	@Column(name = "email", nullable = false, unique = true, length = 100)
	private String email;

	@NotBlank
	@Size(min = 8, max = 255)
	@Column(name = "password", nullable = false, length = 255)
	private String password;

	@Column(name = "result_type", length = 50)
	private String resultType;
}
