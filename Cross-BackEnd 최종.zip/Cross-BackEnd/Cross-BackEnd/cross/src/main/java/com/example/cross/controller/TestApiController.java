package com.example.cross.controller;

import com.example.cross.dto.QuestionDto;
import com.example.cross.dto.ResultDto;
import com.example.cross.dto.SubmitRequestDto;
import com.example.cross.service.TestService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/test")
@RequiredArgsConstructor
public class TestApiController {

	private final TestService testService;

	@GetMapping("/questions")
	public ResponseEntity<List<QuestionDto>> getQuestions() {
		List<QuestionDto> questions = testService.getQuestions();
		return ResponseEntity.ok(questions);
	}

	@PostMapping("/submit")
	public ResponseEntity<ResultDto> submitTest(@Valid @RequestBody SubmitRequestDto submitRequestDto) {
		ResultDto result = testService.calculateResult(submitRequestDto);
		return ResponseEntity.ok(result);
	}
}
