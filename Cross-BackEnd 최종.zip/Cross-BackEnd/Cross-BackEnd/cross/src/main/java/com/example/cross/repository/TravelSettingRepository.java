package com.example.cross.repository;

import com.example.cross.entity.TravelSetting;
import com.example.cross.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TravelSettingRepository extends JpaRepository<TravelSetting, Long> {
    List<TravelSetting> findByUser(User user);
    Optional<TravelSetting> findTopByUserOrderByIdDesc(User user);
}


