package com.example.cross.config;

import com.example.cross.entity.Place;
import com.example.cross.repository.PlaceRepository;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {

    @Bean
    public ApplicationRunner seedPlaces(PlaceRepository placeRepository) {
        return args -> {
            if (placeRepository.count() == 0) {
                Place p1 = new Place();
				p1.setName("Central Park");
				p1.setDescription("자연 속 힐링 산책로와 넓은 공원.");
				p1.setAddress("New York, NY");

                Place p2 = new Place();
				p2.setName("Namsan Tower");
				p2.setDescription("도심 핵심 전망 명소, 야경과 효율적인 동선.");
				p2.setAddress("Seoul, South Korea");

				Place p3 = new Place();
				p3.setName("Jeju Olle Trail");
				p3.setDescription("자연과 함께하는 힐링 트레킹 코스.");
				p3.setAddress("Jeju, South Korea");

				Place p4 = new Place();
				p4.setName("Louvre Museum");
				p4.setDescription("문화와 역사, 미술관 탐방에 최적.");
				p4.setAddress("Paris, France");

				Place p5 = new Place();
				p5.setName("Shibuya Crossing");
				p5.setDescription("도심 탐험과 액티비티가 어울리는 랜드마크.");
				p5.setAddress("Tokyo, Japan");

                placeRepository.save(p1);
                placeRepository.save(p2);
				placeRepository.save(p3);
				placeRepository.save(p4);
				placeRepository.save(p5);
            }
        };
    }
}


