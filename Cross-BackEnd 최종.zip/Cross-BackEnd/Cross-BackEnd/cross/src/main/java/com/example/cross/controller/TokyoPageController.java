package com.example.cross.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/place")
public class TokyoPageController {

    @GetMapping("/tokyo")
    public String tokyo(Model model) {
        model.addAttribute("title", "도쿄타워 (Tokyo Tower)");
        model.addAttribute("image", "https://images.unsplash.com/photo-1513407030348-c983a97b98d8?q=80&w=2072&auto=format&fit=crop");
        model.addAttribute("description", "도쿄타워는 일본 도쿄의 상징적인 랜드마크로, 1958년 완공된 333m 높이의 철골 구조물입니다. 에펠탑을 모델로 한 디자인으로, 방송 송전탑으로 시작해 현재는 전망대와 관광 시설로 유명합니다.");
        model.addAttribute("address", "4-chome 2-8, Shibakoen, Minato 105-0011 Tokyo Prefecture");
        model.addAttribute("price", "메인 데크(150m) 성인 : 1500엔\n탑데크 투어(150m & 250m) : 3300엔 (웹 예약 기준)");
        model.addAttribute("hours", "09:00 ~ 22:30 (최종 입장은 종료 30분전까지)");
        model.addAttribute("phone", "+81 3-3433-5111");
        model.addAttribute("website", "https://www.tokyotower.co.jp");
        return "place-tokyo";
    }
}


