package com.example.cross.dto;

public class RecommendedPlaceDto {
	private String name;
	private String description;
	private String address;
	private String source;
	private int score;
	private String reason;

	public RecommendedPlaceDto() {
	}

	public RecommendedPlaceDto(String name, String description, String address,
							   String source, int score, String reason) {
		this.name = name;
		this.description = description;
		this.address = address;
		this.source = source;
		this.score = score;
		this.reason = reason;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
}

