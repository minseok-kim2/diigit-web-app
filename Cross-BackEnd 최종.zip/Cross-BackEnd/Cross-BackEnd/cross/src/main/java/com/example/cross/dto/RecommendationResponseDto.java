package com.example.cross.dto;

import java.time.LocalDate;
import java.util.List;

public class RecommendationResponseDto {
	private String userType;
	private String destination;
	private LocalDate startDate;
	private LocalDate endDate;
	private String numPeople;
	private List<RecommendedPlaceDto> places;
	private List<RouteStepDto> route;

	public RecommendationResponseDto() {
	}

	public RecommendationResponseDto(String userType, String destination, LocalDate startDate,
									 LocalDate endDate, String numPeople, List<RecommendedPlaceDto> places,
									 List<RouteStepDto> route) {
		this.userType = userType;
		this.destination = destination;
		this.startDate = startDate;
		this.endDate = endDate;
		this.numPeople = numPeople;
		this.places = places;
		this.route = route;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getNumPeople() {
		return numPeople;
	}

	public void setNumPeople(String numPeople) {
		this.numPeople = numPeople;
	}

	public List<RecommendedPlaceDto> getPlaces() {
		return places;
	}

	public void setPlaces(List<RecommendedPlaceDto> places) {
		this.places = places;
	}

	public List<RouteStepDto> getRoute() {
		return route;
	}

	public void setRoute(List<RouteStepDto> route) {
		this.route = route;
	}
}

