package com.example.cross.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class AnswerDto {
    private String code;   // 선택지 코드 (예: "A", "B")
    private String text;   // 선택지 내용
}

