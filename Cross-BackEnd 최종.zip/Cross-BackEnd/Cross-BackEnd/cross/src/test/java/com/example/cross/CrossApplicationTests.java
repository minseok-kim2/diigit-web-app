package com.example.cross;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrossApplicationTests {

	@Test
	void contextLoads() {
	}

}
