package kr.ac.shinhan.dto;

import java.util.List;

public class RouteResponse {
	private List<WaypointDto> orderedWaypoints;
	private double totalDistanceKm;
	private int totalTimeMinutes;

	public RouteResponse(List<WaypointDto> orderedWaypoints, double totalDistanceKm, int totalTimeMinutes) {
		this.orderedWaypoints = orderedWaypoints;
		this.totalDistanceKm = totalDistanceKm;
		this.totalTimeMinutes = totalTimeMinutes;
	}

	public List<WaypointDto> getOrderedWaypoints() {
		return orderedWaypoints;
	}

	public double getTotalDistanceKm() {
		return totalDistanceKm;
	}

	public int getTotalTimeMinutes() {
		return totalTimeMinutes;
	}
}

