package kr.ac.shinhan.dto;

import jakarta.validation.constraints.NotNull;
import java.util.List;

public class RouteRequest {
	@NotNull
	private Double startLat;

	@NotNull
	private Double startLng;

	@NotNull
	private Double endLat;

	@NotNull
	private Double endLng;

	private List<WaypointDto> waypoints;

	public Double getStartLat() {
		return startLat;
	}

	public void setStartLat(Double startLat) {
		this.startLat = startLat;
	}

	public Double getStartLng() {
		return startLng;
	}

	public void setStartLng(Double startLng) {
		this.startLng = startLng;
	}

	public Double getEndLat() {
		return endLat;
	}

	public void setEndLat(Double endLat) {
		this.endLat = endLat;
	}

	public Double getEndLng() {
		return endLng;
	}

	public void setEndLng(Double endLng) {
		this.endLng = endLng;
	}

	public List<WaypointDto> getWaypoints() {
		return waypoints;
	}

	public void setWaypoints(List<WaypointDto> waypoints) {
		this.waypoints = waypoints;
	}
}

