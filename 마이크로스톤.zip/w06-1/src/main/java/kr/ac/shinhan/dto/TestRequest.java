package kr.ac.shinhan.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.Map;

public class TestRequest {
	@NotEmpty
	private Map<String, Integer> answers;

	@NotBlank
	private String travelerType;

	public Map<String, Integer> getAnswers() {
		return answers;
	}

	public void setAnswers(Map<String, Integer> answers) {
		this.answers = answers;
	}

	public String getTravelerType() {
		return travelerType;
	}

	public void setTravelerType(String travelerType) {
		this.travelerType = travelerType;
	}
}

