package kr.ac.shinhan.config;

import kr.ac.shinhan.domain.Destination;
import kr.ac.shinhan.repository.DestinationRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {
	@Bean
	public CommandLineRunner seedDestinations(DestinationRepository destinationRepository) {
		return args -> {
			if (destinationRepository.count() > 0) {
				return;
			}

			destinationRepository.save(Destination.builder()
				.name("서울 남산타워")
				.region("서울")
				.category("도시 전망")
				.tags("야경,커플,전망")
				.description("서울 야경을 한눈에 볼 수 있는 대표 명소")
				.latitude(37.5512)
				.longitude(126.9882)
				.baseScore(4.6)
				.build());

			destinationRepository.save(Destination.builder()
				.name("부산 해운대")
				.region("부산")
				.category("해변")
				.tags("바다,휴식,가족")
				.description("사계절 인기 있는 부산 대표 해변")
				.latitude(35.1587)
				.longitude(129.1604)
				.baseScore(4.7)
				.build());

			destinationRepository.save(Destination.builder()
				.name("제주 성산일출봉")
				.region("제주")
				.category("자연")
				.tags("일출,등산,자연")
				.description("제주도의 대표 자연유산, 일출 명소")
				.latitude(33.4588)
				.longitude(126.9425)
				.baseScore(4.8)
				.build());
		};
	}
}

