package kr.ac.shinhan.service;

import java.util.ArrayList;
import java.util.List;
import kr.ac.shinhan.dto.RouteRequest;
import kr.ac.shinhan.dto.RouteResponse;
import kr.ac.shinhan.dto.WaypointDto;
import org.springframework.stereotype.Service;

@Service
public class RouteService {
	private static final double AVERAGE_SPEED_KMH = 35.0;

	public RouteResponse buildRoute(RouteRequest request) {
		List<WaypointDto> ordered = new ArrayList<>();
		ordered.add(new WaypointDto(request.getStartLat(), request.getStartLng(), "START"));
		if (request.getWaypoints() != null) {
			ordered.addAll(request.getWaypoints());
		}
		ordered.add(new WaypointDto(request.getEndLat(), request.getEndLng(), "END"));

		double totalDistance = 0.0;
		for (int i = 0; i < ordered.size() - 1; i++) {
			WaypointDto from = ordered.get(i);
			WaypointDto to = ordered.get(i + 1);
			totalDistance += haversineKm(from.getLat(), from.getLng(), to.getLat(), to.getLng());
		}

		int totalTimeMinutes = (int) Math.ceil((totalDistance / AVERAGE_SPEED_KMH) * 60);
		return new RouteResponse(ordered, round(totalDistance, 2), totalTimeMinutes);
	}

	private double haversineKm(double lat1, double lon1, double lat2, double lon2) {
		double dLat = Math.toRadians(lat2 - lat1);
		double dLon = Math.toRadians(lon2 - lon1);
		double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
			+ Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
			* Math.sin(dLon / 2) * Math.sin(dLon / 2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		return 6371.0 * c;
	}

	private double round(double value, int scale) {
		double factor = Math.pow(10, scale);
		return Math.round(value * factor) / factor;
	}
}

