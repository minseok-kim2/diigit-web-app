package kr.ac.shinhan.dto;

public class WaypointDto {
	private Double lat;
	private Double lng;
	private String name;

	public WaypointDto() {
	}

	public WaypointDto(Double lat, Double lng, String name) {
		this.lat = lat;
		this.lng = lng;
		this.name = name;
	}

	public Double getLat() {
		return lat;
	}

	public void setLat(Double lat) {
		this.lat = lat;
	}

	public Double getLng() {
		return lng;
	}

	public void setLng(Double lng) {
		this.lng = lng;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}

