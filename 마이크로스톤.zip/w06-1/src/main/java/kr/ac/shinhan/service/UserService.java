package kr.ac.shinhan.service;

import java.time.LocalDateTime;
import java.util.Set;
import kr.ac.shinhan.domain.Role;
import kr.ac.shinhan.domain.User;
import kr.ac.shinhan.dto.LoginRequest;
import kr.ac.shinhan.dto.RegisterRequest;
import kr.ac.shinhan.repository.UserRepository;
import kr.ac.shinhan.security.JwtUtil;
import kr.ac.shinhan.security.UserPrincipal;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {
	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;
	private final JwtUtil jwtUtil;

	public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
		this.userRepository = userRepository;
		this.passwordEncoder = passwordEncoder;
		this.jwtUtil = jwtUtil;
	}

	@Transactional
	public String register(RegisterRequest request) {
		if (userRepository.existsByEmail(request.getEmail())) {
			throw new IllegalArgumentException("이미 가입된 이메일입니다.");
		}

		User user = User.builder()
			.email(request.getEmail())
			.password(passwordEncoder.encode(request.getPassword()))
			.name(request.getName())
			.roles(Set.of(Role.USER))
			.createdAt(LocalDateTime.now())
			.build();

		userRepository.save(user);
		return jwtUtil.generateToken(user);
	}

	@Transactional(readOnly = true)
	public String login(LoginRequest request) {
		User user = userRepository.findByEmail(request.getEmail())
			.orElseThrow(() -> new IllegalArgumentException("이메일 또는 비밀번호가 올바르지 않습니다."));

		if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
			throw new IllegalArgumentException("이메일 또는 비밀번호가 올바르지 않습니다.");
		}

		return jwtUtil.generateToken(user);
	}

	@Transactional(readOnly = true)
	public User getCurrentUser(UserPrincipal principal) {
		return principal.getUser();
	}
}

