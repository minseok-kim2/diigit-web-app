package kr.ac.shinhan.controller;

import jakarta.validation.Valid;
import kr.ac.shinhan.dto.RouteRequest;
import kr.ac.shinhan.dto.RouteResponse;
import kr.ac.shinhan.service.RouteService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/routes")
public class RouteController {
	private final RouteService routeService;

	public RouteController(RouteService routeService) {
		this.routeService = routeService;
	}

	@PostMapping
	public ResponseEntity<RouteResponse> buildRoute(@Valid @RequestBody RouteRequest request) {
		return ResponseEntity.ok(routeService.buildRoute(request));
	}
}

