package kr.ac.shinhan.dto;

import java.util.List;

public class RecommendationResponse {
	private String travelerType;
	private List<DestinationDto> destinations;

	public RecommendationResponse(String travelerType, List<DestinationDto> destinations) {
		this.travelerType = travelerType;
		this.destinations = destinations;
	}

	public String getTravelerType() {
		return travelerType;
	}

	public List<DestinationDto> getDestinations() {
		return destinations;
	}
}

