package kr.ac.shinhan.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import kr.ac.shinhan.domain.PersonalityTest;
import kr.ac.shinhan.domain.User;
import kr.ac.shinhan.dto.TestRequest;
import kr.ac.shinhan.repository.PersonalityTestRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TestService {
	private final PersonalityTestRepository testRepository;
	private final ObjectMapper objectMapper;

	public TestService(PersonalityTestRepository testRepository, ObjectMapper objectMapper) {
		this.testRepository = testRepository;
		this.objectMapper = objectMapper;
	}

	@Transactional
	public PersonalityTest saveTest(User user, TestRequest request) {
		String json;
		try {
			json = objectMapper.writeValueAsString(request.getAnswers());
		} catch (JsonProcessingException e) {
			throw new IllegalArgumentException("테스트 답변 저장에 실패했습니다.");
		}

		PersonalityTest test = PersonalityTest.builder()
			.user(user)
			.answersJson(json)
			.travelerType(request.getTravelerType())
			.createdAt(LocalDateTime.now())
			.build();

		return testRepository.save(test);
	}
}

