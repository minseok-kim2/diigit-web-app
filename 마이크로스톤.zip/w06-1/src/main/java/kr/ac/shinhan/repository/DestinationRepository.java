package kr.ac.shinhan.repository;

import java.util.List;
import kr.ac.shinhan.domain.Destination;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DestinationRepository extends JpaRepository<Destination, Long> {
	List<Destination> findByRegionIgnoreCase(String region);
}

