package kr.ac.shinhan.controller;

import jakarta.validation.Valid;
import kr.ac.shinhan.dto.RecommendationRequest;
import kr.ac.shinhan.dto.RecommendationResponse;
import kr.ac.shinhan.security.UserPrincipal;
import kr.ac.shinhan.service.RecommendationService;
import kr.ac.shinhan.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/recommendations")
public class RecommendationController {
	private final RecommendationService recommendationService;
	private final UserService userService;

	public RecommendationController(RecommendationService recommendationService, UserService userService) {
		this.recommendationService = recommendationService;
		this.userService = userService;
	}

	@PostMapping
	public ResponseEntity<RecommendationResponse> recommend(
		@AuthenticationPrincipal UserPrincipal principal,
		@Valid @RequestBody RecommendationRequest request
	) {
		RecommendationResponse response = recommendationService.recommend(userService.getCurrentUser(principal), request);
		return ResponseEntity.ok(response);
	}
}

