package kr.ac.shinhan.service;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import kr.ac.shinhan.domain.Destination;
import kr.ac.shinhan.domain.PersonalityTest;
import kr.ac.shinhan.domain.User;
import kr.ac.shinhan.dto.DestinationDto;
import kr.ac.shinhan.dto.RecommendationRequest;
import kr.ac.shinhan.dto.RecommendationResponse;
import kr.ac.shinhan.repository.DestinationRepository;
import kr.ac.shinhan.repository.PersonalityTestRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RecommendationService {
	private final DestinationRepository destinationRepository;
	private final PersonalityTestRepository testRepository;

	public RecommendationService(DestinationRepository destinationRepository, PersonalityTestRepository testRepository) {
		this.destinationRepository = destinationRepository;
		this.testRepository = testRepository;
	}

	@Transactional(readOnly = true)
	public RecommendationResponse recommend(User user, RecommendationRequest request) {
		PersonalityTest latestTest = testRepository.findTopByUserOrderByCreatedAtDesc(user)
			.orElseThrow(() -> new IllegalStateException("여행 성향 테스트 결과가 없습니다."));

		List<Destination> destinations = destinationRepository.findByRegionIgnoreCase(request.getRegion());
		if (destinations.isEmpty()) {
			destinations = destinationRepository.findAll();
		}

		String travelerType = latestTest.getTravelerType();
		String theme = request.getTheme() == null ? "" : request.getTheme().toLowerCase(Locale.KOREA);

		List<DestinationDto> scored = destinations.stream()
			.map(destination -> toDtoWithScore(destination, travelerType, theme))
			.sorted(Comparator.comparingDouble(DestinationDto::getScore).reversed())
			.limit(request.getMaxCount())
			.collect(Collectors.toList());

		return new RecommendationResponse(travelerType, scored);
	}

	private DestinationDto toDtoWithScore(Destination destination, String travelerType, String theme) {
		double score = destination.getBaseScore();
		String tags = destination.getTags().toLowerCase(Locale.KOREA);

		if (!theme.isBlank() && tags.contains(theme)) {
			score += 2.0;
		}
		if (travelerType != null && !travelerType.isBlank()) {
			score += travelerType.length() % 3;
		}

		return new DestinationDto(
			destination.getId(),
			destination.getName(),
			destination.getRegion(),
			destination.getCategory(),
			destination.getTags(),
			destination.getDescription(),
			destination.getLatitude(),
			destination.getLongitude(),
			score
		);
	}
}

