package kr.ac.shinhan.dto;

public class DestinationDto {
	private Long id;
	private String name;
	private String region;
	private String category;
	private String tags;
	private String description;
	private double latitude;
	private double longitude;
	private double score;

	public DestinationDto(Long id, String name, String region, String category, String tags, String description,
		double latitude, double longitude, double score) {
		this.id = id;
		this.name = name;
		this.region = region;
		this.category = category;
		this.tags = tags;
		this.description = description;
		this.latitude = latitude;
		this.longitude = longitude;
		this.score = score;
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getRegion() {
		return region;
	}

	public String getCategory() {
		return category;
	}

	public String getTags() {
		return tags;
	}

	public String getDescription() {
		return description;
	}

	public double getLatitude() {
		return latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public double getScore() {
		return score;
	}
}

