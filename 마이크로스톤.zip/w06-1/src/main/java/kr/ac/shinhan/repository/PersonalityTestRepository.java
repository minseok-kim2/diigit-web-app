package kr.ac.shinhan.repository;

import java.util.Optional;
import kr.ac.shinhan.domain.PersonalityTest;
import kr.ac.shinhan.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PersonalityTestRepository extends JpaRepository<PersonalityTest, Long> {
	Optional<PersonalityTest> findTopByUserOrderByCreatedAtDesc(User user);
}

