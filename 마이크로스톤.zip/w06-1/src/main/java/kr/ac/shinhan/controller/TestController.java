package kr.ac.shinhan.controller;

import jakarta.validation.Valid;
import kr.ac.shinhan.dto.TestRequest;
import kr.ac.shinhan.security.UserPrincipal;
import kr.ac.shinhan.service.TestService;
import kr.ac.shinhan.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/tests")
public class TestController {
	private final TestService testService;
	private final UserService userService;

	public TestController(TestService testService, UserService userService) {
		this.testService = testService;
		this.userService = userService;
	}

	@PostMapping
	public ResponseEntity<Void> submitTest(@AuthenticationPrincipal UserPrincipal principal,
		@Valid @RequestBody TestRequest request) {
		testService.saveTest(userService.getCurrentUser(principal), request);
		return ResponseEntity.ok().build();
	}
}

