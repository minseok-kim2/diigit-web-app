package kr.ac.shinhan.domain;

public enum Role {
	USER,
	ADMIN
}

