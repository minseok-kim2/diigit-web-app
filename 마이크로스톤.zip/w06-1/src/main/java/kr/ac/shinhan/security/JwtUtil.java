package kr.ac.shinhan.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Date;
import kr.ac.shinhan.config.JwtProperties;
import kr.ac.shinhan.domain.User;
import org.springframework.stereotype.Component;

@Component
public class JwtUtil {
	private final JwtProperties jwtProperties;

	public JwtUtil(JwtProperties jwtProperties) {
		this.jwtProperties = jwtProperties;
	}

	public String generateToken(User user) {
		Instant now = Instant.now();
		Instant expiresAt = now.plusSeconds(jwtProperties.getExpirationMinutes() * 60);

		return Jwts.builder()
			.subject(String.valueOf(user.getId()))
			.claim("email", user.getEmail())
			.claim("roles", user.getRoles())
			.issuedAt(Date.from(now))
			.expiration(Date.from(expiresAt))
			.signWith(Keys.hmacShaKeyFor(jwtProperties.getSecret().getBytes(StandardCharsets.UTF_8)))
			.compact();
	}

	public Long getUserId(String token) {
		Claims claims = parseClaims(token);
		return Long.valueOf(claims.getSubject());
	}

	public String getEmail(String token) {
		Claims claims = parseClaims(token);
		return claims.get("email", String.class);
	}

	private Claims parseClaims(String token) {
		return Jwts.parser()
			.verifyWith(Keys.hmacShaKeyFor(jwtProperties.getSecret().getBytes(StandardCharsets.UTF_8)))
			.build()
			.parseSignedClaims(token)
			.getPayload();
	}
}

